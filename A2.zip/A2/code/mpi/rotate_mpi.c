#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpi.h>
#include <time.h>

void readPGM(const char *filename, int ***image, int *width, int *height) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        fprintf(stderr, "Error opening file %s\n", filename);
        exit(1);
    }

    char magic[3];
    fscanf(file, "%2s", magic);
    if (magic[0] != 'P' || magic[1] != '2') {
        fprintf(stderr, "Invalid PGM format\n");
        exit(1);
    }

    fscanf(file, "%d %d", width, height);
    int maxVal;
    fscanf(file, "%d", &maxVal);

    *image = (int **)malloc(*height * sizeof(int *));
    for (int i = 0; i < *height; ++i) {
        (*image)[i] = (int *)malloc(*width * sizeof(int));
        for (int j = 0; j < *width; ++j) {
            fscanf(file, "%d", &(*image)[i][j]);
        }
    }

    fclose(file);
}

void rotateImage(int **original, int ***rotated, int originalWidth, int originalHeight, double angle) {
    // Convert angle to radians
    double radians = angle * -M_PI / 180.0;

    // Calculate rotated bounding box dimensions
    int rotatedWidth = (int)(fabs(originalWidth * cos(radians)) + fabs(originalHeight * sin(radians)));
    int rotatedHeight = (int)(fabs(originalHeight * cos(radians)) + fabs(originalWidth * sin(radians)));

    // Calculate centers for the original and rotated images
    int originalCenterX = originalWidth / 2;
    int originalCenterY = originalHeight / 2;
    int rotatedCenterX = rotatedWidth / 2;
    int rotatedCenterY = rotatedHeight / 2;

    // Allocate memory for the rotated image array
    *rotated = (int **)calloc(rotatedHeight, sizeof(int *));
    for (int i = 0; i < rotatedHeight; ++i) {
        (*rotated)[i] = (int *)calloc(rotatedWidth, sizeof(int));
        if ((*rotated)[i] == NULL) {
            fprintf(stderr, "Memory allocation error\n");
            exit(1);
        }
    }

    // Initialize the rotated image with zeros
    for (int i = 0; i < rotatedHeight; ++i) {
        for (int j = 0; j < rotatedWidth; ++j) {
            (*rotated)[i][j] = 0;
        }
    }

    for (int i = 0; i < originalHeight; ++i) {
        for (int j = 0; j < originalWidth; ++j) {
            // Coordinates relative to the center of the original image
            int x = j - originalCenterX;
            int y = i - originalCenterY;

            // Apply rotation with floating-point precision
            double newXf = x * cos(radians) - y * sin(radians);
            double newYf = x * sin(radians) + y * cos(radians);

            // Round to the nearest integer and shift to the center of the rotated image
            int newX = (int)(round(newXf + rotatedCenterX));
            int newY = (int)(round(newYf + rotatedCenterY));

            // Check boundaries against rotated image dimensions
            if (newX >= 0 && newX < rotatedWidth && newY >= 0 && newY < rotatedHeight) {
                (*rotated)[newY][newX] = original[i][j];
            }
        }
    }
}

void freeImage(int **image, int height) {
    for (int i = 0; i < height; ++i) {
        free(image[i]);
    }
    free(image);
}

void printPGM(const char *filename, int **image, int width, int height) {
    FILE *file = fopen(filename, "w");

    if (file == NULL) {
        fprintf(stderr, "Error opening file %s\n", filename);
        exit(1);
    }

    fprintf(file, "P2\n%d %d\n255\n", width, height);

    for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            fprintf(file, "%d ", image[i][j]);
        }
        fprintf(file, "\n");
    }

    fclose(file);
}

void saveRotatedImage(int **rotatedImage, int rotatedWidth, int rotatedHeight, double rotationDegree) {
    char outputFilename[30];
    snprintf(outputFilename, sizeof(outputFilename), "rotated_{%.0f}.pgm", rotationDegree );
    printPGM(outputFilename, rotatedImage, rotatedWidth, rotatedHeight);
}

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);

    int numProcesses, rank;
    MPI_Comm_size(MPI_COMM_WORLD, &numProcesses);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (argc != 2) {
        if (rank == 0) {
            fprintf(stderr, "Usage: %s {rotation_degree}\n", argv[0]);
        }
        MPI_Finalize();
        return 1;
    }

    double rotationDegree = atof(argv[1]);
    int totalIterations = 1; // Only save one rotated image
    int iterationsPerProcess = totalIterations / numProcesses;

    MPI_Barrier(MPI_COMM_WORLD);
    double start_time = MPI_Wtime();

    for (int iteration = rank * iterationsPerProcess; iteration < (rank + 1) * iterationsPerProcess; ++iteration) {
        int width, height;
        int **originalImage;

        if (iteration == 0) {
            // Read PGM file (assuming the PGM file is in the same directory as the executable)
            readPGM("im.pgm", &originalImage, &width, &height);
        }

        // Broadcast image dimensions to all processes
        MPI_Bcast(&width, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&height, 1, MPI_INT, 0, MPI_COMM_WORLD);

        // Calculate rotated dimensions
        int rotatedWidth, rotatedHeight;
        rotatedWidth = (int)(fabs(width * cos(rotationDegree * M_PI / 180.0)) + fabs(height * sin(rotationDegree * M_PI / 180.0)));
        rotatedHeight = (int)(fabs(height * cos(rotationDegree * M_PI / 180.0)) + fabs(width * sin(rotationDegree * M_PI / 180.0)));

        int **rotatedImage = NULL;
        rotateImage(originalImage, &rotatedImage, width, height, rotationDegree);

        // Save rotated image to a new PGM file
        saveRotatedImage(rotatedImage, rotatedWidth, rotatedHeight, rotationDegree);

        // Free memory
        freeImage(rotatedImage, rotatedHeight);

        if (iteration == 0) {
            freeImage(originalImage, height);
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double end_time = MPI_Wtime();

    double local_time = end_time - start_time;
    double total_time;

    MPI_Reduce(&local_time, &total_time, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("Total Execution Time: %f seconds\n", total_time);
        printf("Rotated image successfully generated and saved.\n");
    }

    MPI_Finalize();
    return 0;
}