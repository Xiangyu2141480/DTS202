#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <omp.h>

// Read PGM file
int **readPGM(const char *filename, int *width, int *height, int *maxval) {
    FILE *file;
    int **pixels;
    int i, j;

    file = fopen(filename, "rb");
    if (file == NULL) {
        perror("Unable to open file for reading");
        exit(EXIT_FAILURE);
    }

    fscanf(file, "P2\n%d %d\n%d\n", width, height, maxval);

    pixels = (int **)malloc(*height * sizeof(int *));
    for (i = 0; i < *height; i++) {
        pixels[i] = (int *)malloc(*width * sizeof(int));
        for (j = 0; j < *width; j++) {
            fscanf(file, "%d", &pixels[i][j]);
        }
    }

    fclose(file);
    return pixels;
}

// Write PGM file
void writePGM(const char *filename, int width, int height, int maxval, int **pixels) {
    FILE *file;
    int i, j;

    file = fopen(filename, "wb");
    if (file == NULL) {
        perror("Unable to open file for writing");
        exit(EXIT_FAILURE);
    }

    fprintf(file, "P2\n%d %d\n%d\n", width, height, maxval);

    for (i = 0; i < height; i++) {
        for (j = 0; j < width; j++) {
            fprintf(file, "%d ", pixels[i][j]);
        }
        fprintf(file, "\n");
    }

    fclose(file);
}

void rotateBlock(int **original, int ***rotated, int startX, int startY, int blockWidth, int blockHeight, int originalCenterX, int originalCenterY, int rotatedCenterX, int rotatedCenterY, double cosRadians, double sinRadians, int rotatedWidth, int rotatedHeight) {
    for (int i = startY; i < startY + blockHeight; ++i) {
        for (int j = startX; j < startX + blockWidth; ++j) {
            int x = j - originalCenterX;
            int y = i - originalCenterY;

            double newXf = x * cosRadians - y * sinRadians;
            double newYf = x * sinRadians + y * cosRadians;

            int newX = (int)(round(newXf + rotatedCenterX));
            int newY = (int)(round(newYf + rotatedCenterY));

            if (newX >= 0 && newX < rotatedWidth && newY >= 0 && newY < rotatedHeight) {
                (*rotated)[newY][newX] = original[i][j];
            }
        }
    }
}

void rotateImage(int **original, int ***rotated, int originalWidth, int originalHeight, double angle) {
    double radians = angle * -M_PI / 180.0;
    double cosRadians = cos(radians);
    double sinRadians = sin(radians);

    int rotatedWidth = (int)(fabs(originalWidth * cosRadians) + fabs(originalHeight * sinRadians));
    int rotatedHeight = (int)(fabs(originalHeight * cosRadians) + fabs(originalWidth * sinRadians));

    int originalCenterX = originalWidth / 2;
    int originalCenterY = originalHeight / 2;
    int rotatedCenterX = rotatedWidth / 2;
    int rotatedCenterY = rotatedHeight / 2;

    *rotated = (int **)calloc(rotatedHeight, sizeof(int *));
    for (int i = 0; i < rotatedHeight; ++i) {
        (*rotated)[i] = (int *)calloc(rotatedWidth, sizeof(int));
        if ((*rotated)[i] == NULL) {
            fprintf(stderr, "Memory allocation error\n");
            exit(1);
        }
    }

    // Initialize the rotated image with zeros
#pragma omp parallel for
    for (int i = 0; i < rotatedHeight; ++i) {
        for (int j = 0; j < rotatedWidth; ++j) {
            (*rotated)[i][j] = 0;
        }
    }

    // Divide the image into four blocks and rotate each block in parallel
#pragma omp parallel sections
    {
#pragma omp section
        {
            rotateBlock(original, rotated, 0, 0, originalWidth / 2, originalHeight / 2, originalCenterX, originalCenterY, rotatedCenterX, rotatedCenterY, cosRadians, sinRadians, rotatedWidth, rotatedHeight);
        }
#pragma omp section
        {
            rotateBlock(original, rotated, originalWidth / 2, 0, originalWidth / 2, originalHeight / 2, originalCenterX, originalCenterY, rotatedCenterX, rotatedCenterY, cosRadians, sinRadians, rotatedWidth, rotatedHeight);
        }
#pragma omp section
        {
            rotateBlock(original, rotated, 0, originalHeight / 2, originalWidth / 2, originalHeight / 2, originalCenterX, originalCenterY, rotatedCenterX, rotatedCenterY, cosRadians, sinRadians, rotatedWidth, rotatedHeight);
        }
#pragma omp section
        {
            rotateBlock(original, rotated, originalWidth / 2, originalHeight / 2, originalWidth / 2, originalHeight / 2, originalCenterX, originalCenterY, rotatedCenterX, rotatedCenterY, cosRadians, sinRadians, rotatedWidth, rotatedHeight);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s {rotation_degree} {num_threads}\n", argv[0]);
        return 1;
    }

    // Convert the rotation degree argument to a double
    double rotationDegree = atof(argv[1]);

    // Set the number of threads
    int numThreads = atoi(argv[2]);
    omp_set_num_threads(numThreads);

    // Example image dimensions (replace with your actual dimensions)
    int width, height, maxval;
    int **originalImage, **rotatedImage;

    // Read PGM file (assuming the PGM file is in the same directory as the executable)
    originalImage = readPGM("im.pgm", &width, &height, &maxval);

    // Get the time when the program starts execution
    double start_time = omp_get_wtime();

    // Perform image rotation with the specified angle
    rotateImage(originalImage, &rotatedImage, width, height, rotationDegree);

    // Get the time when the program ends execution
    double end_time = omp_get_wtime();

    // Calculate and print the total execution time
    double total_time = end_time - start_time;
    printf("Total Execution Time: %f seconds\n", total_time);

    // Obtain the dimensions of the rotated image
    int rotatedWidth, rotatedHeight;
    rotatedWidth = (int)(fabs(width * cos(rotationDegree * M_PI / 180.0)) + fabs(height * sin(rotationDegree * M_PI / 180.0)));
    rotatedHeight = (int)(fabs(height * cos(rotationDegree * M_PI / 180.0)) + fabs(width * sin(rotationDegree * M_PI / 180.0)));

    // Generate the output file name based on the rotation degree
    char outputFileName[256];
    sprintf(outputFileName, "rotate-image{%.0f}.pgm", rotationDegree);

    // Save the rotated image to a new PGM file
    writePGM(outputFileName, rotatedWidth, rotatedHeight, maxval, rotatedImage);

    // Free allocated memory
    for (int i = 0; i < height; i++) {
        free(originalImage[i]);
    }
    free(originalImage);

    for (int i = 0; i < rotatedHeight; i++) {
        free(rotatedImage[i]);
    }
    free(rotatedImage);

    printf("Rotated image successfully generated and saved as: %s\n", outputFileName);

    return 0;
}





