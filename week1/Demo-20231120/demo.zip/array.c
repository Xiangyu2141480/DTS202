#include <stdio.h>

int main() {
    int list[] = {
      1,
      2,
      15,
      2001
    };

    printf("%d\n", list[0]);
    printf("%d\n", list[5]);

    int two_d[2][3] = {3, 2, 5, 5, 1, 2, 5};
    int *p = two_d;
    printf("%d", *(p + 1));
}