#include <stdio.h>

int main(int argc, char *argv[]) {
    FILE *f = fopen("test.txt", "r");

    int digit, curr;
    while ((curr = fgetc(f)) != EOF) {
        ungetc(curr, f);

        fscanf(f, "%d", &digit);
        printf("%d \n", digit);
    }
    fclose(f);
    return 0;
}