#include <stdio.h>

typedef struct {
    int account_number;
    char *first_name;
    char *last_name;
} USER;

int main() {
    USER user1, *user2;
    user2 = &user1;
    user1.account_number = 100;
    user1.first_name = "DTS202";
    user1.last_name = "XJTLU";

    printf("%s at %s", user1.first_name, user2->last_name);
    return 0;
}