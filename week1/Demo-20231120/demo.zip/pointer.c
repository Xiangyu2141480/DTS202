#include <stdio.h>

int main(int argc, char* argv[]) {
    int a = 0;
    int *b = &a;

    return 0;
}