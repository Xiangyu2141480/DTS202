#include <stdio.h>

void edit_array(int array[]) {
    array[0] = 2;

    printf("Size of array: %d", sizeof(array));
}

int main() {
    int list[] = {
            1,
            2,
            15,
            2001
    };

    edit_array(list);

//    printf("%d \n", list[0]);

    return 0;
}